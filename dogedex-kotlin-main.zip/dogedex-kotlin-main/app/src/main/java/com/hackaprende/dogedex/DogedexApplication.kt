package com.hackaprende.dogedex

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DogedexApplication : Application()