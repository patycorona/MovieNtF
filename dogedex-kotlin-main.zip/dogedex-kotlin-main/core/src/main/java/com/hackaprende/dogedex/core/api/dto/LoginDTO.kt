package com.hackaprende.dogedex.core.api.dto

class LoginDTO(
    val email: String,
    val password: String,
)