package com.hackaprende.dogedex.core.api.responses

import com.hackaprende.dogedex.core.api.dto.DogDTO

class DogResponse(val dog: DogDTO)