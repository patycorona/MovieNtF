package com.hackaprende.dogedex.core.api.responses

class LoginApiResponse {
}