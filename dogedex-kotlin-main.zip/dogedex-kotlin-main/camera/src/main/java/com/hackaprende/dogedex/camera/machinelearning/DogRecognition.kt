package com.hackaprende.dogedex.camera.machinelearning

data class DogRecognition(val id: String,
                          val confidence: Float)