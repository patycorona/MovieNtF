package com.hackaprende.dogedex.camera

const val MAX_RECOGNITION_DOG_RESULTS = 5
const val MODEL_PATH = "model.tflite"
const val LABEL_PATH = "labels.txt"