package com.hackaprende.dogedex.auth.auth

object AuthNavDestinations {
    const val LoginScreenDestination = "login_screen"
    const val SignUpScreenDestination = "sign_up_screen"
}